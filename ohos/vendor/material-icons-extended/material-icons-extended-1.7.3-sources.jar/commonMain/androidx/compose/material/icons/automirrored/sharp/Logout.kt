/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material.icons.automirrored.sharp

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

public val Icons.AutoMirrored.Sharp.Logout: ImageVector
    get() {
        if (_logout != null) {
            return _logout!!
        }
        _logout = materialIcon(name = "AutoMirrored.Sharp.Logout", autoMirror = true) {
            materialPath {
                moveTo(5.0f, 5.0f)
                lineToRelative(7.0f, 0.0f)
                lineToRelative(0.0f, -2.0f)
                lineToRelative(-9.0f, 0.0f)
                lineToRelative(0.0f, 18.0f)
                lineToRelative(9.0f, 0.0f)
                lineToRelative(0.0f, -2.0f)
                lineToRelative(-7.0f, 0.0f)
                close()
            }
            materialPath {
                moveTo(21.0f, 12.0f)
                lineToRelative(-4.0f, -4.0f)
                lineToRelative(0.0f, 3.0f)
                lineToRelative(-8.0f, 0.0f)
                lineToRelative(0.0f, 2.0f)
                lineToRelative(8.0f, 0.0f)
                lineToRelative(0.0f, 3.0f)
                close()
            }
        }
        return _logout!!
    }

private var _logout: ImageVector? = null
